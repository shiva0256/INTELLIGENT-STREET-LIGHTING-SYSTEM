# ISS Dashboard — Setup & Run

## Folder structure

```
iss_dashboard/
├── app.py
├── requirements.txt
├── iss_fault_model.pkl       ← copy from your Colab download
├── iss_fault_scaler.pkl      ← copy from your Colab download
└── templates/
    └── dashboard.html
```

## Steps

### 1. Copy your model files here
Place `iss_fault_model.pkl` and `iss_fault_scaler.pkl` in the same folder as `app.py`.

### 2. Create virtual environment (recommended)
```bash
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # Linux/Mac
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run
```bash
python app.py
```

### 5. Open browser
```
http://localhost:5000
```

## Notes
- Dashboard auto-refreshes every 15 seconds (matches Node 01 TX interval).
- Data is fetched from Firebase `/nodes/node_01/latest`.
- Fault prediction uses your Random Forest model (5 classes).
- If model files are missing, the dashboard still shows live sensor data — just no prediction.
