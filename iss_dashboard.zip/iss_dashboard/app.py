import os
import pickle
import numpy as np
import requests
from flask import Flask, render_template, jsonify

app = Flask(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
FIREBASE_URL = "https://iss-cloud-17e3c-default-rtdb.firebaseio.com"
NODE_ID      = "node_01"

MODEL_PATH  = "iss_fault_model.pkl"
SCALER_PATH = "iss_fault_scaler.pkl"

FAULT_LABELS = {
    0: ("Normal",         "normal"),
    1: ("Overvoltage",    "warning"),
    2: ("Undervoltage",   "warning"),
    3: ("Short Circuit",  "danger"),
    4: ("Power Outage",   "danger"),
}

# ── Load model once at startup ────────────────────────────────────────────────
model, scaler = None, None

def load_model():
    global model, scaler
    try:
        with open(MODEL_PATH, "rb") as f:
            model = pickle.load(f)
        with open(SCALER_PATH, "rb") as f:
            scaler = pickle.load(f)
        print("[ISS] Model and scaler loaded successfully.")
    except FileNotFoundError as e:
        print(f"[ISS] WARNING: {e} — predictions will be unavailable until model files are present.")

load_model()

# ── Helpers ───────────────────────────────────────────────────────────────────
def fetch_latest():
    """Fetch /nodes/node_01/latest from Firebase REST API."""
    url = f"{FIREBASE_URL}/nodes/{NODE_ID}/latest.json"
    try:
        resp = requests.get(url, timeout=5)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        print(f"[ISS] Firebase fetch error: {e}")
        return None

def predict(data: dict):
    """Run fault prediction on payload data. Returns label string and severity."""
    if model is None or scaler is None:
        return "Model Not Loaded", "unknown", -1

    try:
        features = np.array([[
            data.get("voltage_rms", 0),
            data.get("current_rms", 0),
            data.get("power_w",     0),
            data.get("lux",         0),
        ]])
        scaled   = scaler.transform(features)
        pred_idx = int(model.predict(scaled)[0])
        label, severity = FAULT_LABELS.get(pred_idx, ("Unknown", "unknown"))
        return label, severity, pred_idx
    except Exception as e:
        print(f"[ISS] Prediction error: {e}")
        return "Prediction Error", "unknown", -1

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("dashboard.html")

@app.route("/api/data")
def api_data():
    """JSON endpoint polled by the dashboard every 15 s."""
    raw = fetch_latest()
    if raw is None:
        return jsonify({"error": "Firebase unreachable"}), 503

    label, severity, pred_idx = predict(raw)

    return jsonify({
        "node_id":      raw.get("node_id", NODE_ID),
        "voltage_rms":  round(raw.get("voltage_rms", 0), 2),
        "current_rms":  round(raw.get("current_rms", 0), 3),
        "power_w":      round(raw.get("power_w",     0), 2),
        "lux":          round(raw.get("lux",         0), 1),
        "pir_state":    int(raw.get("pir_state",    0)),
        "relay_state":  int(raw.get("relay_state",  0)),
        "night_mode":   int(raw.get("night_mode",   0)),
        "fault_label":  label,
        "fault_severity": severity,
        "fault_index":  pred_idx,
    })

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
